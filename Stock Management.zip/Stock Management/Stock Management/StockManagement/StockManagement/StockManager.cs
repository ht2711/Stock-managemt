﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StockManagement
{
    public class StockManager
    {
        private SortedDictionary<int, StockItem> stockItems;

        public StockManager()
        {
            stockItems = new SortedDictionary<int, StockItem>();
        }

        //public StockItem AddQuantityToStockItem(int code, int quantityToAdd)
        //{
        //    StockItem stockItem = stockItems[code];
        //    stockItem.AddQuantity(quantityToAdd);
        //    return stockItem;
        //}
        public StockItem AddQuantityToStockItem(int code, int quantityToAdd)
        {
            if (stockItems.ContainsKey(code))
            {
                StockItem stockItem = stockItems[code];
                stockItem.AddQuantity(quantityToAdd);
                return stockItem;
            }
            else
            {
                throw new Exception($"Stock item {code} not found. Quantity not added.");
            }
        }
        //public StockItem CreateStockItem(int code, string name, int quantityInStock)
        //{
        //    StockItem stockItem = new StockItem(code, name, quantityInStock);
        //    stockItems.Add(code, stockItem);
        //    return stockItem;
        //}
        public StockItem CreateStockItem(int code, string name, int quantityInStock)
        {
            if (stockItems.ContainsKey(code))
            {
                throw new Exception($"Item code {code} already exists. Item not added.");
            }
            else
            {
                StockItem stockItem = new StockItem(code, name, quantityInStock);
                stockItems.Add(code, stockItem);
                return stockItem;
            }
        }
        //public StockItem DeleteStockItem(int code)
        //{
        //    StockItem stockItem = stockItems[code];
        //    stockItems.Remove(code);
        //    return stockItem;
        //}
        public StockItem DeleteStockItem(int code)
        {
            if (stockItems.ContainsKey(code))
            {
                StockItem stockItem = stockItems[code];

                if (stockItem.QuantityInStock == 0)
                {
                    stockItems.Remove(code);
                    return stockItem;
                }
                else
                {
                    throw new Exception("Item cannot be deleted because quantity in stock is not zero");
                }
            }
            else
            {
                throw new Exception("Item has not been deleted because it cannot be found");
            }
        }



        //public StockItem FindStockItem(int code)
        //{
        //    return stockItems[code];
        //}

        public StockItem FindStockItem(int code)
        {
            if (stockItems.ContainsKey(code))
            {
                return stockItems[code];
            }
            else
            {
                return null;
            }
        }

        public SortedDictionary<int, StockItem> GetAllStockItems()
        {
            return stockItems;
        }

        //public StockItem RemoveQuantityFromStockItem(int code, int quantityToRemove)
        //{
        //    StockItem stockItem = stockItems[code];
        //    stockItem.SubtractQuantity(quantityToRemove);
        //    return stockItem;
        //}
        public StockItem RemoveQuantityFromStockItem(int code, int quantityToRemove)
        {
            if (stockItems.ContainsKey(code))
            {
                StockItem stockItem = stockItems[code];
                stockItem.SubtractQuantity(quantityToRemove);
                return stockItem;
            }
            else
            {
                throw new Exception($"Stock item {code} not found. Quantity not removed.");
            }
        }
    }
}