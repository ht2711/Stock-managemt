﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Transactions;
using StockManagement;

namespace StockManagement
{
    public class AdminUI
    {
        public StockManager stockMgr;
        public TransactionManager transactionMgr;
        public AdminUI(StockManager stockManager, TransactionManager transactionManager)
        {
            stockMgr = stockManager;
            transactionMgr = transactionManager;
        }
        //public List<string> AddANewItemOfStock(int code, string name, int quantityInStock)
        //{
        //    StockItem stockItem = stockMgr.CreateStockItem(code, name, quantityInStock);
        //    List<string> messages = new List<string>();
        //    messages.Add("New item added to stock.");
        //    transactionMgr.RecordItemAdded(stockItem);
        //    return messages;
        //}

        public List<string> AddANewItemOfStock(int code, string name, int quantityInStock)
        {

            // Kiểm tra xem mặt hàng đã tồn tại hay chưa
            if (IsItemExists(code))
            {
                List<string> messages = new List<string>();
                messages.Add($"Item code 1 already exists. Item not added.");
                return messages;
            }

            StockItem stockItem = stockMgr.CreateStockItem(code, name, quantityInStock);
            List<string> successMessages = new List<string>();
            successMessages.Add($"Item added. Item code: {stockItem.Code}");
            transactionMgr.RecordItemAdded(stockItem);
            return successMessages;
        }

        public bool IsItemExists(int code)
        {
            // Kiểm tra logic để xác định xem một mặt hàng đã tồn tại hay chưa
            List<int> itemCodes = new List<int>(stockMgr.GetAllStockItems().Keys);
            foreach (int itemCode in itemCodes)
            {
                if (itemCode == code)
                {
                    return true; // Mặt hàng đã tồn tại
                }
            }

            return false; // Mặt hàng chưa tồn tại
        }
        //public List<string> AddQuantityToAStockItem(int code, int quantityToAdd)
        //{
        //    StockItem stockItem = stockMgr.AddQuantityToStockItem(code, quantityToAdd);
        //    List<string> messages = new List<string>();
        //    messages.Add("Quantity added to stock item.");
        //    tMgr.RecordQuantityAdded(stockItem, quantityToAdd);
        //    return messages;
        //}
        public List<string> AddQuantityToAStockItem(int code, int quantityToAdd)
        {
            List<string> messages = new List<string>();

            StockItem stockItem = null;
            foreach (var item in stockMgr.GetAllStockItems().Values)
            {
                if (item.Code == code)
                {
                    stockItem = item;
                    break;
                }
            }

            if (stockItem != null)
            {
                stockItem.QuantityInStock += quantityToAdd;
                messages.Add($"Quantity added to item: {code}. New quantity in stock: {stockItem.QuantityInStock}");
                transactionMgr.RecordQuantityAdded(stockItem, quantityToAdd);
            }
            else
            {
                messages.Add($"Stock item {code} not found. Quantity not added.");
            }

            return messages;
        }
        ////public List<string> DeleteAStockItem(int code)
        ////{
        ////    StockItem stockItem = stockMgr.DeleteStockItem(code);
        ////    List<string> messages = new List<string>();
        ////    messages.Add("Stock item deleted.");
        ////    transactionMgr.RecordItemDeleted(stockItem);
        ////    return messages;
        ////}

        public List<string> DeleteAStockItem(int code)
        {
            StockItem stockItem = stockMgr.FindStockItem(code);
            List<string> messages = new List<string>();

            if (stockItem != null)
            {
                stockMgr.DeleteStockItem(code);
                messages.Add($"Item {code} deleted.");
                transactionMgr.RecordItemDeleted(stockItem);
            }
            else
            {
                messages.Add("Item has not been deleted because it cannot be found");
            }

            return messages;
        }

        //public List<string> DeleteAStockItem(int code)
        //{
        //        StockItem stockItem = stockMgr.DeleteStockItem(code);
        //        List<string> messages = new List<string>();
        //        messages.Add("Item 1 deleted.");
        //        transactionMgr.RecordItemDeleted(stockItem);
        //        return messages;

        //}
        //public List<string> RemoveQuantityFromAStockItem(int code, int quantityToRemove)
        //{
        //    StockItem stockItem = stockMgr.RemoveQuantityFromStockItem(code, quantityToRemove);
        //    List<string> messages = new List<string>();
        //    messages.Add("Quantity removed from stock item.");
        //    transactionMgr.RecordQuantityRemoved(stockItem, quantityToRemove);
        //    return messages;
        //}

        public List<string> RemoveQuantityFromAStockItem(int code, int quantityToRemove)
        {
            StockItem stockItem = stockMgr.FindStockItem(code);
            List<string> messages = new List<string>();

            if (stockItem != null)
            {
                if (stockItem.QuantityInStock >= quantityToRemove)
                {
                    stockItem.QuantityInStock -= quantityToRemove;
                    messages.Add($"Quantity removed from item: {code}. New quantity in stock: {stockItem.QuantityInStock}");
                    transactionMgr.RecordQuantityRemoved(stockItem, quantityToRemove);
                }
                else
                {
                    messages.Add($"Insufficient quantity in stock for item: {code}. Quantity not removed.");
                }
            }
            else
            {
                messages.Add($"Stock item {code} not found. Quantity not removed.");
            }

            return messages;
        }

        //public List<string> ViewStockLevels()
        //{
        //    SortedDictionary<int, StockItem> stockItems = stockMgr.GetAllStockItems();
        //    List<string> messages = new List<string>();
        //    messages.Add("Current stock levels:");
        //    foreach (var item in stockItems)
        //    {
        //        messages.Add($"Code: {item.Key}, Name: {item.Value.GetName()}, Quantity: {item.Value.GetQuantityInStock()}");
        //    }
        //    return messages;
        //}
        public List<string> ViewStockLevels()
        {
            List<string> list1 = new List<string>();
            list1.Add("\nStock Levels");
            list1.Add("============");

            if (stockMgr.GetAllStockItems().Count > 0)
            {
                list1.Add("\tItem code\tItem name           \tQuantity in stock");
                foreach (int item in stockMgr.GetAllStockItems().Keys)
                {
                    int code = stockMgr.GetAllStockItems()[item].Code;
                    string name = stockMgr.GetAllStockItems()[item].Name;
                    int quantity = stockMgr.GetAllStockItems()[item].QuantityInStock;
                    list1.Add($"\t{code,-9}\t{name,-20}\t{quantity}");
                }
            }
            else
            {
                list1.Add("No stock items");
            }
            return list1;
        }
        //public List<string> ViewTransactionLog()
        //{
        //    List<Transaction> transactions = transactionMgr.GetAllTransactions();
        //    List<string> messages = new List<string>();
        //    messages.Add("Transaction log:");
        //    foreach (var transaction in transactions)
        //    {
        //        messages.Add(transaction.ToString());
        //    }
        //    return messages;
        //}
      public List<string> ViewTransactionLog()
    {
        List<Transaction> transactions = transactionMgr.GetAllTransactions();
        List<string> messages = new List<string>();
        messages.Add("\nTransaction log");
        messages.Add("===============");

        if (transactions.Count == 0)
        {
            messages.Add("No transactions");
        }
        else
        {
            foreach (var transaction in transactions)
            {
                string message = transaction.TransactionDatetime.ToString("dd/MM/yyyy HH:mm") + " " + transaction.ToString();
                messages.Add(message);
            }
        }

        return messages;
    }


    }
}






