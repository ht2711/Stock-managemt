﻿using System;

namespace StockManagement
{
    public class QuantityRemovedTransaction : Transaction
    {
        private int stockItemCode;
        private string stockItemName;
        private int quantityRemoved;
        private int newQuantityInStock;

        public QuantityRemovedTransaction(DateTime transactionDatetime, int stockItemCode, string stockItemName, int quantityRemoved, int newQuantityInStock)
            : base("Quantity removed", transactionDatetime)
        {
            this.stockItemCode = stockItemCode;
            this.stockItemName = stockItemName;
            this.quantityRemoved = quantityRemoved;
            this.newQuantityInStock = newQuantityInStock;
        }

        public override string ToString()
        {
            return $"{TransactionDatetime.ToString("dd/MM/yyyy HH:mm")} {TransactionName} - Item {stockItemCode}: {stockItemName}. Quantity removed: {quantityRemoved}. New quantity in stock: {newQuantityInStock}";
        }
    }
}
