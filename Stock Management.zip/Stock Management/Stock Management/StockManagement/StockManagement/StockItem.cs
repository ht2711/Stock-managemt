﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StockManagement
{
    public class StockItem
    {
        public int Code;
        public string Name;
        public int QuantityInStock;

        //public StockItem(int code, string name, int qtyInStock)
        //{
        //    this.Code = code;
        //    this.Name = name;
        //    QuantityInStock = qtyInStock;
        //}
        public StockItem(int code, string name, int qtyInStock)
        {
            StringBuilder errorMessage = new StringBuilder();

            if (code <= 0)
                errorMessage.Append("Item code must be a positive integer. ");

            if (name == "")
                errorMessage.Append("Item name cannot be blank. ");
            else if (name.Trim().Length == 0 || name == "    ")
                errorMessage.Append("Item name cannot be just spaces. ");

            if (qtyInStock < 0)
                errorMessage.Append("Quantity cannot be zero or negative. ");

            if (errorMessage.Length > 0)
                throw new ArgumentException(errorMessage.ToString());
            Code = code;
            Name = name;
            QuantityInStock = qtyInStock;
        }

        //public void AddQuantity(int qty)
        //{
        //    QuantityInStock += qty;
        //}
        public void AddQuantity(int qty)
        {
            if (qty <= 0)
                throw new ArgumentException("Quantity cannot be negative");
            if (qty <= 0)
                throw new ArgumentException("Quantity cannot be zero or negative. ");

            QuantityInStock += qty;
        }

        //public void SubtractQuantity(int qty)
        //{
        //    QuantityInStock -= qty;
        //}
        public void SubtractQuantity(int qty)
        {
            if (qty <= 0)
                throw new ArgumentException("Quantity cannot be negative");
            if (qty <= 0)
                throw new ArgumentException("Quantity cannot be zero or negative. ");

            if (qty > QuantityInStock)
                throw new ArgumentException("Insufficient quantity in stock");

            QuantityInStock -= qty;
        }


        public int GetCode()
        {
            return Code;
        }

        public string GetName()
        {
            return Name;
        }

        public int GetQuantityInStock()
        {
            return QuantityInStock;
        }
    }
}
