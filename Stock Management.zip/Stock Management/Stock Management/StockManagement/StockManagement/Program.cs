﻿using System;
using System.Collections.Generic;
using System.Transactions;

namespace StockManagement
{
        public class Program
        {
            public AdminUI adminUI;
            
            public Program()
            {
                adminUI = new AdminUI(new StockManager(), new TransactionManager());
            }

            static void Main(string[] args)
            {
                Program program = new Program();
                program.Run();
            }

            private void Run()
            {
                adminUI = new AdminUI(new StockManager(), new TransactionManager());
                DisplayMenu();
            }

            private void DisplayMenu()
            {
                bool exit = false;
                while (!exit)
                {
                    Console.WriteLine("========== Stock Management System ==========");
                    Console.WriteLine("1. Add a new item of stock");
                    Console.WriteLine("2. Add quantity to a stock item");
                    Console.WriteLine("3. Delete a stock item");
                    Console.WriteLine("4. Remove quantity from a stock item");
                    Console.WriteLine("5. View stock levels");
                    Console.WriteLine("6. View transaction log");
                    Console.WriteLine("0. Exit");

                    int choice = ReadInteger("Enter your choice: ");

                    switch (choice)
                    {
                        case 0:
                            exit = true;
                            break;
                        case 1:
                            AddANewItemOfStock();
                            break;
                        case 2:
                            AddQuantityToAStockItem();
                            break;
                        case 3:
                            DeleteAStockItem();
                            break;
                        case 4:
                            RemoveQuantityFromAStockItem();
                            break;
                        case 5:
                            ViewStockLevels();
                            break;
                        case 6:
                            ViewTransactionLog();
                            break;
                        default:
                            Console.WriteLine("Invalid choice. Please try again.");
                            break;
                    }

                    Console.WriteLine();
                }
            }

            public void DisplayResults(List<string> results)
            {
                foreach (string result in results)
                {
                    Console.WriteLine(result);
                }
            }

            private int ReadInteger(string prompt)
            {
                Console.Write(prompt);
                string input = Console.ReadLine();
                int value;
                while (!int.TryParse(input, out value))
                {
                    Console.WriteLine("Invalid input. Please enter an integer.");
                    Console.Write(prompt);
                    input = Console.ReadLine();
                }
                return value;
            }

            private string ReadString(string prompt)
            {
                Console.Write(prompt);
                return Console.ReadLine();
            }

            private void AddANewItemOfStock()
            {
                int code = ReadInteger("Enter the item code: ");
                string name = ReadString("Enter the item name: ");
                int quantity = ReadInteger("Enter the quantity in stock: ");

                List<string> results = adminUI.AddANewItemOfStock(code, name, quantity);
                DisplayResults(results);
            }

            private void AddQuantityToAStockItem()
            {
                int code = ReadInteger("Enter the item code: ");
                int quantity = ReadInteger("Enter the quantity to add: ");

                List<string> results = adminUI.AddQuantityToAStockItem(code, quantity);
                DisplayResults(results);
            }

            private void DeleteAStockItem()
            {
                int code = ReadInteger("Enter the item code: ");

                List<string> results = adminUI.DeleteAStockItem(code);
                DisplayResults(results);
            }

            private void RemoveQuantityFromAStockItem()
            {
                int code = ReadInteger("Enter the item code: ");
                int quantity = ReadInteger("Enter the quantity to remove: ");

                List<string> results = adminUI.RemoveQuantityFromAStockItem(code, quantity);
                DisplayResults(results);
            }

            private void ViewStockLevels()
            {
                List<string> results = adminUI.ViewStockLevels();
                DisplayResults(results);
            }

            private void ViewTransactionLog()
            {
                List<string> results = adminUI.ViewTransactionLog();
                DisplayResults(results);
            }
        }

    }
