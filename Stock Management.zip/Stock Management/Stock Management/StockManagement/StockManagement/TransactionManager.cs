﻿using System;
using System.Collections.Generic;
using System.Text;


namespace StockManagement
{
    public class TransactionManager
    {
        private List<Transaction> transactions;

        public TransactionManager()
        {
            transactions = new List<Transaction>();
        }
        //public List<Transaction> GetAllTransactions()
        //{
        //    return transactions;
        //}
        public List<Transaction> Transactions
        {
            get { return transactions; }
            set { transactions = value; }
        }


        public List<Transaction> GetAllTransactions()
        {
            return transactions;
        }
        //public void RecordItemAdded(StockItem stockItem)
        //{
        //    Transaction transaction = new ItemAddedTransaction(DateTime.Now, stockItem.GetCode(), stockItem.GetName(), 0);
        //    transactions.Add(transaction);
        //}

        public void RecordItemAdded(StockItem stockItem)
        {
            Transaction transaction = new ItemAddedTransaction(DateTime.Now, stockItem.GetCode(), stockItem.GetName(), 0);
            transactions.Add(transaction);
        }

        //public void RecordItemDeleted(StockItem stockItem)
        //{
        //    Transaction transaction = new ItemDeletedTransaction(DateTime.Now, stockItem.GetCode(), stockItem.GetName());
        //    transactions.Add(transaction);
        //}
        public void RecordItemDeleted(StockItem stockItem)
        {
            Transaction transaction = new ItemDeletedTransaction(DateTime.Now, stockItem.GetCode(), stockItem.GetName());
            transactions.Add(transaction);
        }

        //public void RecordQuantityAdded(StockItem stockItem, int quantityAdded)
        //{
        //    Transaction transaction = new QuantityAddedTransaction(DateTime.Now, stockItem.GetCode(), stockItem.GetName(), quantityAdded, stockItem.GetQuantityInStock());
        //    transactions.Add(transaction);
        //}
        public void RecordQuantityAdded(StockItem stockItem, int quantityAdded)
        {
            Transaction transaction = new QuantityAddedTransaction(DateTime.Now, stockItem.GetCode(), stockItem.GetName(), quantityAdded, stockItem.GetQuantityInStock());
            transactions.Add(transaction);
        }
        //public void RecordQuantityRemoved(StockItem stockItem, int quantityRemoved)
        //{
        //    Transaction transaction = new QuantityRemovedTransaction(DateTime.Now, stockItem.GetCode(), stockItem.GetName(), quantityRemoved, stockItem.GetQuantityInStock());
        //    transactions.Add(transaction);
        //}

        public void RecordQuantityRemoved(StockItem stockItem, int quantityRemoved)
        {
            Transaction transaction = new QuantityRemovedTransaction(DateTime.Now, stockItem.GetCode(), stockItem.GetName(), quantityRemoved, stockItem.GetQuantityInStock());
            transactions.Add(transaction);
        }
    }
}
