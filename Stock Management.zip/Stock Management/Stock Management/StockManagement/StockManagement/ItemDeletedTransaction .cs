﻿using System;

namespace StockManagement
{
    public class ItemDeletedTransaction : Transaction
    {
        private int stockItemCode;
        private string stockItemName;
        //public ItemDeletedTransaction(DateTime transactionDatetime, int stockItemCode, string stockItemName)
        //  : base("Item Deleted", transactionDatetime)
        //{
        //    this.stockItemCode = stockItemCode;
        //    this.stockItemName = stockItemName;
        //}

        public ItemDeletedTransaction(DateTime transactionDatetime, int stockItemCode, string stockItemName)
            : base("Item deleted", transactionDatetime)
        {
            this.stockItemCode = stockItemCode;
            this.stockItemName = stockItemName;
        }
        //public override string ToString()
        //{
        //    return $"{base.ToString()}: Item Code - {stockItemCode}, Item Name - {stockItemName}";
        //}
        public override string ToString()
        {
            return $"{TransactionDatetime.ToString("dd/MM/yyyy HH:mm")} {TransactionName} - Item {stockItemCode}: {stockItemName} deleted.";
        }
    }
}
