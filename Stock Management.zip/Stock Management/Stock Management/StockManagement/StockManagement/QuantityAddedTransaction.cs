﻿using System;

namespace StockManagement
{
    public class QuantityAddedTransaction : Transaction
    {
        private int stockItemCode;
        private string stockItemName;
        private int quantityAdded;
        private int newQuantityInStock;

        public QuantityAddedTransaction(DateTime transactionDatetime, int stockItemCode, string stockItemName, int quantityAdded, int newQuantityInStock)
            : base("Quantity added", transactionDatetime)
        {
            this.stockItemCode = stockItemCode;
            this.stockItemName = stockItemName;
            this.quantityAdded = quantityAdded;
            this.newQuantityInStock = newQuantityInStock;
        }
        //public override string ToString()
        //{
        //    return $"{base.ToString()}: Item Code - {stockItemCode}, Item Name - {stockItemName}, Quantity Added - {quantityAdded}, New Quantity - {newQuantityInStock}";
        //}

        public override string ToString()
        {
            return $"{TransactionDatetime.ToString("dd/MM/yyyy HH:mm")} {TransactionName}   - Item {stockItemCode}: {stockItemName}. Quantity added: {quantityAdded}. New quantity in stock: {newQuantityInStock}";
        }

    }
}
