﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StockManagement
{
    public abstract class Transaction
    {
        public DateTime TransactionDatetime;
        public string TransactionName;

        public Transaction(string name, DateTime dt)
        {
            TransactionDatetime = dt;

            TransactionName = name;
        }
       
        public DateTime GetTransactionDatetime()
        {
            return TransactionDatetime;
        }

        public string GetTransactionName()
        {
            return TransactionName;
        }

        public override string ToString()
        {
            return $"{TransactionDatetime} - {TransactionName}";
        }
    }
}

