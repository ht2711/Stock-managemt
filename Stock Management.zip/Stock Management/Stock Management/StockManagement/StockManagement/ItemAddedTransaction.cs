﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Transactions;

namespace StockManagement
{
    public class ItemAddedTransaction : Transaction
    {
        private int stockItemCode;
        private string stockItemName;
        private int quantityAdded;

        public ItemAddedTransaction(DateTime transactionDatetime, int stockItemCode, string stockItemName, int quantityAdded)
            : base("Item added", transactionDatetime)
        {
            this.stockItemCode = stockItemCode;
            this.stockItemName = stockItemName;
            this.quantityAdded = quantityAdded;
        }
        //public override string ToString()
        //{
        //    return $"{base.ToString()}: Item Code - {stockItemCode}, Item Name - {stockItemName}, Quantity Added - {quantityAdded}";
        //}
        public override string ToString()
        {
            string dateStr = TransactionDatetime.ToString("dd/MM/yyyy HH:mm");
            return $"{dateStr} {TransactionName,-16} - Item {stockItemCode}: {stockItemName} added. Quantity in stock: {quantityAdded}";
        }
    }
}

